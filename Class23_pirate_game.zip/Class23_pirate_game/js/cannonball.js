class CannonBall {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.radius = 30;

        var ballOptions = {isStatic: true};
        this.ball = Bodies.circle(x, y, this.radius, ballOptions);
        World.add(world, this.ball);
        this.image = loadImage("assets/cannonball.png");

        this.trajectory = [];
    }

    display() {
        var ballPos = this.ball.position;
        push();
        imageMode(CENTER);
        image(this.image, ballPos.x, ballPos.y, this.radius, this.radius);
        pop();
        if (this.ball.velocity.x > 0 && ballPos.x > 10) {
            var position = [ballPos.x, ballPos.y];
            this.trajectory.push(position);
        }
        // for (var i = 0; i < this.trajectory.length; i++) {
        //     image(this.image, this.trajectory[i][0], this.trajectory[i][1], 5, 5);
        // }
    }

    ball_shoot() {
        var newAngle = cannon.angle - 28;
        newAngle = newAngle * (3.14 / 180);
        var velocity = p5.Vector.fromAngle(newAngle);
        velocity.mult(0.5);
        Matter.Body.setStatic(this.ball, false);
        Matter.Body.setVelocity(this.ball, {
            x: velocity.x * (180 / 3.14),
            y: velocity.y * (180 / 3.14)
        });
    }
}