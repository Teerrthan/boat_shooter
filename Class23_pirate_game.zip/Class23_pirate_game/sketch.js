var World = Matter.World;
var Engine = Matter.Engine;
var Bodies = Matter.Bodies;
var Body = Matter.Body;
var Constraint = Matter.Constraint;
var canvas, background_img, tower_img, engine, world, ground, cannon, balls = [], boats = [];
var boatAnimation = [];
var boatSpriteData, boatSpriteSheet;
var brokenBoatAnimation = [];
var brokenBoatSpriteData, brokenBoatSpriteSheet;

function preload() {
  background_img = loadImage("assets/background.gif");
  tower_img = loadImage("assets/tower.png");
  boatSpriteData = loadJSON("assets/boat/boat.json");
  boatSpriteSheet = loadImage("assets/boat/boat.png");
  brokenBoatSpriteData = loadJSON("assets/boat/brokenBoat.json");
  brokenBoatSpriteSheet = loadImage("assets/boat/brokenBoat.png");
}


function setup() {
  canvas = createCanvas(1200, 600);
  engine = Engine.create();
  world = engine.world;

  var option = {isStatic: true};
  ground = Bodies.rectangle(0, height - 1, width * 2, 1, option);
  World.add(world, ground);
  tower = Bodies.rectangle(160, 350, 160, 310, option);
  World.add(world, tower)

  cannon = new Cannon(180, 110, 130, 100, 70);
  // cannonball = new CannonBall(cannon.x, cannon.y);
  
  angleMode(DEGREES);
  angle = 50;

  var boatFrame = boatSpriteData.frames;
  for (var i = 0; i < boatFrame.length; i++) {
    var pos = boatFrame[i].position;
    var img = boatSpriteSheet.get(pos.x, pos.y, pos.w, pos.h);
    boatAnimation.push(img);
  }


  var brokenBoatFrame = brokenBoatSpriteData.frames;
  for (var i = 0; i < brokenBoatFrame.length; i++) {
    var pos = brokenBoatFrame[i].position;
    var img = brokenBoatSpriteSheet.get(pos.x, pos.y, pos.w, pos.h);
    brokenBoatAnimation.push(img);
  }
}

function draw() {
  image(background_img, 0, 0, width, height);
  Engine.update(engine);
  rect(ground.position.x, ground.position.y, width * 2, 1);
  push();
  imageMode(CENTER);
  image(tower_img, tower.position.x, tower.position.y, 160, 310);
  pop();

  cannon.display();
  //to display multiple balls
  for (i = 0; i < balls.length; i++) {
    showCannonball(balls[i]);
    collisionWithBoat[i];
  }

  showBoats();
}

function keyReleased() {
  if (keyCode == DOWN_ARROW) {
    balls[balls.length - 1].ball_shoot();
  }
}

function keyPressed() {
  if (keyCode == DOWN_ARROW) {
    cannonball = new CannonBall(cannon.x, cannon.y);
    balls.push(cannonball);
    cannonball.trajectory = [];
  }
}

function showCannonball(ball) {
  if (ball) {
    ball.display();
  }
}

function showBoats() {
  if (boats.length > 0) {
    //after gap, create new boat

    if(boats[boats.length - 1] === undefined || boats[boats.length - 1].body.position.x < width - 300) {
      var positions = [-40, -60, -70, -20];
      var position = random(positions);
      var boat = new Boat(width, height - 50, 170, 170, position, boatAnimation);
      boats.push(boat);
    }
    //displaying the boats
    for (var i = 0; i < boats.length; i++) {
      if (boats[i]) {
        //move the boat
        Matter.Body.setVelocity(boats[i].body, {x: -0.9, y: 0});
        //display the boat
        boats[i].display();
        boats[i].animate();
      }
    }
  } else {
    var boat = new Boat(width, height - 50, 170, 170, -70, boatAnimation)
    boats.push(boat);
  }
}

function collisionWithBoat(index) {
  for (var i = 0; i < boats.length; i++) {
    if (balls[index] !== undefined && boats[i] !== undefined) {
      var collision = Matter.SAT.collides(balls[index].body, boats[i].body);
      
      if (collision.collided) {
        boats[i].remove(i);


        Matter.World.remove(world, balls[index].body);
        delete balls[index];
      }
    }
  }
}

